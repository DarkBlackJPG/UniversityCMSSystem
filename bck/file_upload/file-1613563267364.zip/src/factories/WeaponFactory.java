package factories;

import utility.Spear;
import utility.Spell;
import utility.Sword;

public class WeaponFactory {

    public Spear forgeSpear() {
        return new Spear();
    }

    public Sword forgeSword() {
        return new Sword();
    }

    public Spell writeSpell() {
        return new Spell();
    }
}
