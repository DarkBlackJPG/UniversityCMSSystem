package factories;

import Exceptions.InventoryOverflowException;
import Exceptions.NotWorthyToWieldException;
import implementations.Dragon;
import implementations.Spider;
import implementations.Warrior;
import implementations.Wizard;
import interfaces.Enemy;
import interfaces.Hero;
import interfaces.Weapon;
import utility.Spear;
import utility.Sword;

import java.util.Random;

public class NPCFactory {
    private enum WarriorWeaponTypes {
        SPEAR,
        SWORD
    }
    private WeaponFactory weaponFactory;
    private Random randomHeroGenerator;
    private Random randomEnemyGenerator;
    private Random randomWeaponGenerator;
    private Random numOfWeaponsGenerator;

    public NPCFactory() {
        weaponFactory = new WeaponFactory();
        randomHeroGenerator = new Random();
        randomEnemyGenerator = new Random();
        randomWeaponGenerator = new Random();
        numOfWeaponsGenerator = new Random();
    }

    public Hero createHero() {
        Hero myHero = null;
        int numOfWeapons = Math.abs(numOfWeaponsGenerator.nextInt()) % 2;
        int isWarrior = Math.abs(randomHeroGenerator.nextInt()) % 2;

        if (isWarrior == 1) {
            myHero = new Warrior();
            int weaponType = Math.abs(randomWeaponGenerator.nextInt()) % 2;
            Weapon weapon = null;
            for (int i = 0; i < numOfWeapons; ++i) {
                if (weaponType == WarriorWeaponTypes.SPEAR.ordinal()) {
                    weapon = weaponFactory.forgeSpear();
                } else {
                    weapon = weaponFactory.forgeSword();
                }
                // We can surround the method like this because we are 100% sure that we cannot get any other weapon
                // Note: This could be done via constructor, but I wanted to use this method specifically
                try {
                    myHero.takeWeapon(weapon);
                } catch (InventoryOverflowException | NotWorthyToWieldException e) {
                    e.printStackTrace();
                }
            }
        } else {
            myHero = new Wizard();
            // According to the task, the wizard can only wield spells, therfore I dont need to implemnt any other
            // logic, just a for loop
            Weapon spell;
            for (int i = 0; i < numOfWeapons; ++i) {
                spell = weaponFactory.writeSpell();
                try {
                    myHero.takeWeapon(spell);
                } catch (InventoryOverflowException e) {
                    e.printStackTrace();
                } catch (NotWorthyToWieldException e) {
                    e.printStackTrace();
                }
            }
        }
        return myHero;
    }
    public Enemy createEnemy() {
        Enemy enemy = null;
        int isManSpider = Math.abs(randomEnemyGenerator.nextInt()) % 2;
        if(isManSpider == 1) {
            enemy = new Spider();
        } else {
            enemy = new Dragon();
        }
        return enemy;
    }

}
