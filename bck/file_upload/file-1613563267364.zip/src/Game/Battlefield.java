package Game;

import interfaces.Enemy;
import interfaces.Hero;
import interfaces.NPC;
import interfaces.Weapon;

import java.util.Random;
import java.util.logging.Logger;

/**
 * This class is only used as a Wrapper for shared objects!
 * This is used as a Monitor object
 *
 * The logic behind the usage of this class has two options:
 *
 * Option A:
 *          1. Hero and villain fight
 *          2. Hero dies
 *          3. Weapon falls to the ground
 *
 * Option B:
 *          1. Hero randomly choses to throw away the weapon
 *          2. The weapon falls to the battlefield
 *
 * Its important to note that you cannot stack weapons on the battlefield. There can only be one at a single time!
 *
 *
 *
 */
public class Battlefield {
    private Weapon discarded;
    private NPC myTurn;
    private Hero activeHero;
    private Enemy activeEnemy;
    private NPC winner;
    private Random randomAttack;
    private static final Logger LOGGER = Logger.getLogger(Battlefield.class.getName());

    public Battlefield() {
        myTurn = null;
        randomAttack = new Random();
    }

    public synchronized Weapon getBattlefieldWeapon() {
        Weapon returnWeapon = discarded;
        discarded = null;
        if (returnWeapon != null)
            LOGGER.info(String.format("%s picked up %s.", activeHero.getName(), returnWeapon.getName()));

        return returnWeapon;
    }

    public synchronized void setBattlefieldWeapon(Weapon discarded) {
        this.discarded = discarded;
    }

    public synchronized Hero getActiveHero() {
        return activeHero;
    }

    public synchronized void setActiveHero(Hero activeHero) {
        this.activeHero = activeHero;
        if (activeEnemy != null ) {
            myTurn = activeEnemy;
            notifyAll();
        }
    }

    public synchronized Enemy getActiveEnemy() {
        return activeEnemy;
    }

    public synchronized void setActiveEnemy(Enemy activeEnemy) {
        this.activeEnemy = activeEnemy;
        if (activeHero != null ) {
            myTurn = activeHero;
            notifyAll();
        }
    }

    public synchronized void takeAttackTurn(NPC attacker) throws InterruptedException {
        if (winner != null) {
            Thread.currentThread().interrupt();
            return;
        }

        // Trebalo je drugacije da se implementira odluka, ja sam mahinalno uradio da ide prvo jedan pa drugi
        if (attacker == activeEnemy && randomAttack.nextInt() % 101 > 50) {
            if (activeHero == null)
                return;
            LOGGER.info(String.format("%s attacked %s with [nisam stigao] || Hero HP: %d || Enemy HP: %d", activeEnemy.getName(), activeHero.getName(), activeHero.getHealth(), activeEnemy.getHealth()));
            attacker.attack(activeHero);
            myTurn = activeHero;
        } else {
            if (activeEnemy == null)
                return;
            LOGGER.info(String.format("%s attacked %s with [nisam stigao] || Hero HP: %d || Enemy HP: %d",  activeHero.getName(),  activeEnemy.getName(),activeHero.getHealth(), activeEnemy.getHealth()));
            attacker.attack(activeEnemy);
            myTurn = activeEnemy;
        }

        notifyAll();
    }

    public synchronized void declareWinner(NPC loser) {
        if (winner != null) {
            Thread.currentThread().interrupt();
            return;
        }
        if(loser == activeEnemy) {
            winner = activeHero;
            LOGGER.info(String.format("%s won against %s.", activeHero.getName(), activeEnemy.getName()));

        } else {
            LOGGER.info(String.format("%s won against %s.", activeEnemy.getName(), activeHero.getName()));
            winner = activeEnemy;
        }
        myTurn = null;
        activeEnemy = null;
        activeHero = null;
    }
}
