package Game;

import factories.NPCFactory;
import interfaces.Enemy;
import interfaces.Hero;

public class Simulation {
    private final static int NUM_NPC = 5;

    public static void main(String[] args) {
        Battlefield battlefield = new Battlefield();
        HeroThread[] heroes = new HeroThread[NUM_NPC];
        EnemyThread[] enemies = new EnemyThread[NUM_NPC];
        NPCFactory npcFactory = new NPCFactory();

        for (int i = 0; i < NUM_NPC; ++i) {
            heroes[i] = new HeroThread(npcFactory.createHero(), battlefield);
            enemies[i] = new EnemyThread(npcFactory.createEnemy(), battlefield);
        }

        for (int i = 0; i < NUM_NPC; ++i) {
            heroes[i].start();
            enemies[i].start();

            try {
                heroes[i].join();
                enemies[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
