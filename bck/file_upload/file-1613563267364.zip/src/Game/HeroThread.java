package Game;

import Exceptions.InventoryOverflowException;
import Exceptions.InventoryUnderflowException;
import Exceptions.NotWorthyToWieldException;
import interfaces.Enemy;
import interfaces.Hero;
import interfaces.Weapon;

import java.util.Random;

public class HeroThread extends Thread {
    private Hero myHero;
    private Battlefield battlefield;
    private Random discardWeapon;
    public HeroThread(Hero myHero, Battlefield battlefield) {
        this.myHero = myHero;
        this.battlefield = battlefield;
        this.discardWeapon = new Random();
    }

    @Override
    public void run() {
        battlefield.setActiveHero(myHero);
        Weapon battleFieldWeapon = battlefield.getBattlefieldWeapon();
        if (battleFieldWeapon != null) {
            try {
                myHero.takeWeapon(battleFieldWeapon);
            } catch (InventoryOverflowException e) {
                e.printStackTrace();
            } catch (NotWorthyToWieldException e) {
                e.printStackTrace();
            }
        }
        while(true) {
            if(this.isInterrupted()) {
                break;
            }
            if (Math.abs(discardWeapon.nextGaussian()) <= 0.01 ){
                try {
                    myHero.throwActiveWeapon();
                } catch (InventoryUnderflowException e) {
                    e.printStackTrace();
                }
            }
            try {
                battlefield.takeAttackTurn(myHero);
            } catch (InterruptedException e) {
                break;
            }
            if(myHero.getHealth() <= 0) {
                battlefield.declareWinner(myHero);
                try {
                    battlefield.setBattlefieldWeapon(myHero.throwActiveWeapon());
                } catch (InventoryUnderflowException e) {
                    e.printStackTrace();
                }
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}
