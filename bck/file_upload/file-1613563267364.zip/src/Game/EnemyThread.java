package Game;

import Exceptions.InventoryUnderflowException;
import interfaces.Enemy;

public class EnemyThread extends Thread{
    private Enemy myEnemy;
    private Battlefield battlefield;
    public EnemyThread(Enemy myEnemy, Battlefield battlefield) {
        this.myEnemy = myEnemy;
        this.battlefield = battlefield;
    }

    @Override
    public void run() {
        battlefield.setActiveEnemy(myEnemy);
        while(true) {
            if (isInterrupted()) {
                break;
            }
            try {
                battlefield.takeAttackTurn(myEnemy);
            } catch (InterruptedException e) {
                break;
            }
            if(myEnemy.getHealth() <= 0) {
                battlefield.declareWinner(myEnemy);
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}
