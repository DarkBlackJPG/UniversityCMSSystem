package implementations;

import Exceptions.InventoryOverflowException;
import Exceptions.NotWorthyToWieldException;
import interfaces.Enemy;
import interfaces.Hero;
import interfaces.NPC;
import interfaces.Weapon;

public class Wizard extends Hero {
    private static final int HEALTH = 150;

    public Wizard() {
        super(HEALTH);
    }

    @Override
    public void attack(NPC enemy) {
        int DPH = 0;
        if (activeWeapon != -1) {
           DPH = inventory[activeWeapon].getDPH();
        }
        enemy.takeDamage(DPH);

    }

    @Override
    public String getName() {
        return "Warrior";
    }
}
