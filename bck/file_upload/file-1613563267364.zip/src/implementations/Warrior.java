package implementations;

import Exceptions.InventoryOverflowException;
import Exceptions.NotWorthyToWieldException;
import interfaces.Enemy;
import interfaces.Hero;
import interfaces.NPC;
import interfaces.Weapon;

public class Warrior extends Hero {
    private static final int HEALTH = 100;

    public Warrior() {
        super(HEALTH);
    }

    @Override
    public void attack(NPC enemy) {
        int DPH = inventory[activeWeapon].getDPH();
        enemy.takeDamage(DPH);
    }

    @Override
    public String getName() {
        return "Warrior";
    }
}
