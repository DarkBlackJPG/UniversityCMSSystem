package implementations;

import interfaces.Enemy;
import interfaces.Hero;
import interfaces.NPC;

public class Dragon extends Enemy {
    private enum AttackTypes {
        HIT(0),
        FIRE(1);

        private final int value;

        AttackTypes(int i) {
            value = i;
        }

        public int getValue() {
            return value;
        }
    };
    private static final int[] attacks;
    static {
        attacks = new int[2];
        attacks[AttackTypes.HIT.value] = 5;
        attacks[AttackTypes.FIRE.value] = 20;
    }
    public Dragon() {

    }
    public String getName() {
        return "Dragon";
    }
    @Override
    public void attack(NPC hero) {
        hero.takeDamage(attacks[getAttack()]);
    }
}
