package interfaces;

import Exceptions.InventoryOverflowException;
import Exceptions.InventoryUnderflowException;
import Exceptions.NotWorthyToWieldException;

public abstract class Hero extends NPC{
    protected static final int maxCapacity = 2;

    protected Weapon[] inventory;
    protected int capacity;
    protected int activeWeapon;


    protected Hero(int health) {
        this.inventory = new Weapon[2];
        this.capacity = 0;
        this.activeWeapon = 0;
        this.health = health;
    }

    public void takeWeapon(Weapon newWeapon) throws InventoryOverflowException, NotWorthyToWieldException {
        if(this.capacity + 1 > maxCapacity) {
            throw new InventoryOverflowException();
        }
        if (newWeapon.canWield(this.getClass())) {
            // This can be done because we have inventory of two and if we have capacity == 1 then
            // We know that the next available slot is (activeWeapon + 1) % 2
            int nextSlot = (activeWeapon + 1 ) % 2;
            activeWeapon = nextSlot;
            inventory[nextSlot] = newWeapon;
            capacity++;
        } else {
            throw new NotWorthyToWieldException(getName(), newWeapon.getName());
        }

    }

    public Weapon throwActiveWeapon() throws InventoryUnderflowException {
        if (capacity == 0) throw new InventoryUnderflowException();
        Weapon discarded = inventory[activeWeapon];
        inventory[activeWeapon] = null;
        switchCurrentWeapon();
        if (inventory[activeWeapon] == null) {
            activeWeapon = -1;
        }
        capacity--;
        return discarded;
    }

    public Weapon getActiveWeapon() {
        return inventory[activeWeapon];
    }



    public void switchCurrentWeapon() {
        activeWeapon = (activeWeapon + 1) % 2;
    }
}
