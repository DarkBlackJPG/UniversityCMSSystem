package interfaces;

import java.util.HashSet;
import java.util.Set;

public abstract class Weapon {
    private Set<Class> acceptableUsers;

    public Weapon() {
        this.acceptableUsers = new HashSet<>();
    }

    public abstract int getDPH();

    protected Weapon addAcceptableUser(Class user) {
        acceptableUsers.add(user);
        return this;
    }

    public boolean canWield(Class user) {
        return acceptableUsers.contains(user);
    }
    public abstract String getName();
}
