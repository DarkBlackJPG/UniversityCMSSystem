package interfaces;

public abstract class NPC {
    protected int health;

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }
    public abstract void attack(NPC enemy);

    public void takeDamage(int damage) {
        health -= damage;
    }

    public abstract String getName();
}
