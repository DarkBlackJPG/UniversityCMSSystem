package interfaces;

import java.util.Random;

public abstract class Enemy extends NPC{
    private Random random;

    public Enemy() {
        this.random = new Random();
        this.health = 250;
    }

    protected int getAttack() {
        return Math.abs(random.nextInt() % 2);
    }
}
