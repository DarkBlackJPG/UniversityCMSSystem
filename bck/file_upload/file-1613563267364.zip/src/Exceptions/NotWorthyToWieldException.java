package Exceptions;

public class NotWorthyToWieldException extends Exception{
    private String userClass;
    private String weaponClass;

    public NotWorthyToWieldException(String userClass, String weaponClass) {
        this.userClass = userClass;
        this.weaponClass = weaponClass;
    }

    @Override
    public String getMessage() {
        return String.format("%s is not worthy to wield %s", userClass, weaponClass);
    }
}
