package Exceptions;

public class InventoryUnderflowException extends Exception{
    @Override
    public String getMessage() {
        return "Inventory is empty!";
    }
}
