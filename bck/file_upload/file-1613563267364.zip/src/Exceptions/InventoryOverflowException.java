package Exceptions;

public class InventoryOverflowException extends Exception{
    @Override
    public String getMessage() {
        return "Inventory is full!";
    }
}
