package utility;

import implementations.Warrior;
import interfaces.Weapon;

public class Sword extends Weapon {

    public Sword() {
        addAcceptableUser(Warrior.class);
    }
    @Override
    public int getDPH() {
        return 20;
    }

    @Override
    public String getName() {
        return "Sword";
    }
}
