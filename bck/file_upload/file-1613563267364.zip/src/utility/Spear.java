package utility;

import implementations.Warrior;
import interfaces.Hero;
import interfaces.Weapon;

import java.util.Set;

public class Spear extends Weapon {

    public Spear() {
        addAcceptableUser(Warrior.class);
    }

    @Override
    public int getDPH() {
        return 15;
    }

    @Override
    public String getName() {
        return "Spear";
    }
}
