package utility;

import implementations.Warrior;
import implementations.Wizard;
import interfaces.Weapon;

public class Spell extends Weapon {

    public Spell() {
        addAcceptableUser(Wizard.class);
    }

    @Override
    public int getDPH() {
        return 10;
    }

    @Override
    public String getName() {
        return "Spell";
    }
}
